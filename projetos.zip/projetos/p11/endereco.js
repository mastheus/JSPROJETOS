// Javascript - Objeto Endereço
// Criar um objeto endereco que contem: // Rua // Cidade // СЕР // exibirEndereco(endereco)
let endereco = {
    Rua: 'dos pãezinhos quentinhos',
    Cidade:': São Janeiro',
    Cер:': 9192-000'
};
function exibirEndereco(endereco) {
    for (let chave in endereco)
        console.log(chave, endereco[chave]);
}
    exibirEndereco(endereco);