let a = 'vermelho';
let b =  'azul';
let с = a;
a = b;
 b = c;
console. log(a);
console.log(b);

